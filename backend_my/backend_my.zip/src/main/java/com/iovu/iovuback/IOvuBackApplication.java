package com.iovu.iovuback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IOvuBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(IOvuBackApplication.class, args);
	}

	private String name;
}
