package com.iovu.iovuback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class IOvuBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
